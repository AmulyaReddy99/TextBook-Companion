# page number: 75

#meals
appetizers<-c("soup","juice")
main<-c("meat", "fish", "vegetable dish")
desert<-c("ice cream","cake")

ans<-length(appetizers)*length(main)*length(desert)
print(ans)